DROP TABLE IF EXISTS `#__jdm_articles`;

DROP TABLE IF EXISTS `#__jdm_article_stashes`;

DROP TABLE IF EXISTS `#__jdm_languages`;

DROP TABLE IF EXISTS `#__jdm_manuals`;

DROP TABLE IF EXISTS `#__jdm_menus`;

DROP TABLE IF EXISTS `#__jdm_menu_headings`;

DROP TABLE IF EXISTS `#__jdm_menu_stashes`;

